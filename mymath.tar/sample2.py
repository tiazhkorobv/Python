"""
This file demonstrates basic arithmetic operations in Python.
It defines a function 'add' to perform addition of two numbers and
then calculates and prints the sum of 4 and 5 using the 'add' function.
"""
def add(number1, number2):
    """This func makes adding"""
    return number1 + number2

NUM1 = 4
NUM2 = 5
TOTAL = add(NUM1, NUM2)
print(f"The sum of {NUM1} and {NUM2} is {TOTAL}".format())
